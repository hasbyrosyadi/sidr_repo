import sys
import json
import urllib
import urllib2
import base64

from django.conf import settings
from django.contrib.auth.hashers import check_password

from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.models import User, Group

__author__ = 'afifun'


class Auth(ModelBackend):
    def authenticate(self, username=None, password=None, **kwargs):
        user = None
        if username and password:

            auth = AuthenticationHelper()
            data = auth.authenticate(username, password)

            sys.stdout.write('%s\n' % str(data))

            try:
                if data['state'] == 1:
                    # user is authenticated, then create new user if not exist
                    user, user_is_new = User.objects.get_or_create(username=str(data['username']).strip(),
                                                                   first_name=str(data['nama']).strip())

                    if user_is_new:
                        sys.stdout('create new user %s\n' % user.username)

                    group, group_is_new = Group.objects.get_or_create(name=data['nama_role'])

                    if group_is_new:
                        sys.stdout.write('create new group %s\n' % group.name)

                    user.groups.add(group)

            except Exception as e:
                sys.stderr.write('%s\n' % str(e))

        return user


class AuthenticationHelper(object):
    service_endpoints = []
    groups = ()
    user_special = []

    def __init__(self, **kwargs):
        try:
            self.services_tuple = kwargs['auth_url']
        except KeyError:
            self.service_endpoints = ['https://api.cs.ui.ac.id/authentication/ldap/v2/',
                                      'https://api.cs.ui.ac.id/authentication/akun/v2/']

        try:
            self.groups = kwargs['groups']
        except KeyError:

            if hasattr(settings, 'CSAUTH_ALLOWED_ROLE'):
                self.groups = settings.CSAUTH_ALLOWED_ROLE
            else:
                self.groups = ['mahasiswa', 'staf']

    def authenticate(self, username=None, password=None):
        """
            method berfungsi untuk melakukan otentikasi user pada sistem
            pengecekan akun user dilakukan pada tiga tempat yaitu ldap, login_akun (akun pc kelas)
            dan database local sistem.
            user terotentikasi jika user terotentikasi pada salah satu tempat
            return object user - jika terotentikasi else return None

        """
        data = self.authenticate_user_from_service(username, password)

        if data['state'] != 1:
            """
                user tidak ada di ldap dan akun maka cek user di database sistem
                pengecekan ini untuk user2 khusus, spt admin, user yang tidak punya akun ldap atau akun pc kelas
            """
            data = self.authenticate_user_from_localdb(username, password)

        # return None jika user tidak ada di service dan di database sistem else return object user
        return data

    @staticmethod
    def get_user(user_id):
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None

    @staticmethod
    def authenticate_user_from_localdb(username=None, password=None):
        sys.stdout.write('cek di database sistem\n')
        data = {'state': 0}
        try:
            user = User.objects.get(username=username)
            pswd_valid = check_password(password, user.password)

            if not pswd_valid:
                return data
            else:
                data.update({'state': 1, 'username': username, 'kodeidentitas': None})

        except User.DoesNotExist:
            sys.stderr.write('%s tidak ada di database sistem\n' % username)

        return data

    def authenticate_user_from_service(self, username=None, password=None):
        data = {'state': 0}

        if len(self.service_endpoints) > 0:
            for url in self.service_endpoints:
                try:
                    url = str(url).strip()
                    payloads = urllib.urlencode({'username': username, 'password': password})
                    req = urllib2.Request(url, payloads)
                    endpoint_username = settings.CSAUTH_USERNAME if hasattr(settings, 'CSAUTH_USERNAME') else ''
                    endpoint_password = settings.CSAUTH_PASSWORD if hasattr(settings, 'CSAUTH_PASSWORD') else ''
                    authorization = base64.encodestring('%s:%s' %
                                                        (endpoint_username, endpoint_password)
                                                        ).replace('\n', '')
                    req.add_header("Authorization", "Basic %s" % authorization)
                    response = urllib2.urlopen(req, timeout=100000).read()
                    data = json.loads(response)

                    if data['state'] == 1:
                        # user is authenticated, break, return data
                        break
                    else:
                        # state = 0
                        continue
                except Exception as e:
                    sys.stderr.write('%s\n' % str(e))
                    continue
        return data
