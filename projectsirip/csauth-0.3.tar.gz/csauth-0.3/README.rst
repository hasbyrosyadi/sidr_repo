======
CSAUTH
======

Merupakan aplikasi sederhana yang dapat digunakan dilingkungan fasilkom UI untuk
melakuan otentikasi pada sistem akun fasilkom UI

Quick Start

1. Masukkan "CSAUTH" pada INSTALLED_APPS seperti berikut::

    INSTALLED_APPS = [
        ...
        'csauth',
    ]

2. Masukkan csauth URLconf pad urls.py proyek seperti berikut::

    url(r'^csauth/', include('csauth.urls', namespace='csauth')),

   Adapun contoh urls.py:

    from django.conf.urls import url, include
    from django.views.generic import RedirectView
    from django.contrib import admin

    urlpatterns = [
        url(r'^$', RedirectView.as_view(pattern_name='csauth:login', permanent=False),),
        url(r'^admin/', admin.site.urls),
        url(r'^csauth/', include('csauth.urls', namespace='csauth')),
    ]

3. Tambahkan username dan password untuk melakukan otentikasi pada settings.py:

CSAUTH_USERNAME = 'sikontrak'
CSAUTH_PASSWORD = 'api4k0ntrak'

LOGIN_REDIRECT_URL = '/csauth/home/'

LOGIN_URL = '/csauth/login/'

LOGOUT_URL = '/csauth/logout/'

# AUTH_FAIL_URL = '/authFailed/'

AUTHENTICATION_BACKENDS = (
    'csauth.backend.Auth',
)


4. Jalankan development server dan buka http://127.0.0.1:8000/