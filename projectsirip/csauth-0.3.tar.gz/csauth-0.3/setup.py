import os
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README.rst')) as readme:
    README = readme.read()

# allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

setup(
    name='csauth',
    version='0.3',
    packages=find_packages(),
    include_package_data=True,
    license='Faculty of Computer Science Universitas Indonesia License',  # example license
    description='Merupakan aplikasi sederhana yang dapat digunakan dilingkungan fasilkom UI untuk '
                'melakukan otentikasi pada sistem akun fasilkom UI.',
    long_description=README,
    url='https://www.cs.ui.ac.id/',
    author='Moh. Afifun Naily',
    author_email='afifunanaily@cs.ui.ac.id',
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'Framework :: Django :: 1.10',  # replace "X.Y" as appropriate
        'Intended Audience :: Developers',
        'License :: OSI Approved ::  License',  # example license
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        # Replace these appropriately if you are stuck on Python 2.
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 2.7',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
)